const hamburgerIcon = document.getElementById('hamburger-icon');
const navMenu = document.querySelector('.navmenu');

hamburgerIcon.addEventListener('click', () => {
  navMenu.classList.toggle('active');
});
